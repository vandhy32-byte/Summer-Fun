
export class AchievementSystem{
 constructor(){this.list=[];}
 unlock(name){if(!this.list.includes(name))this.list.push(name);}
}
