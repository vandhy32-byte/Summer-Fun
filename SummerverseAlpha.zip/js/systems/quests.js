
export class QuestSystem{
 constructor(){this.quests=[{name:'First Steps',complete:false}];}
}
