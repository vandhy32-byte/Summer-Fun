
export class Player{
 constructor(){
  this.x=200; this.y=200;
  this.level=1; this.hp=100; this.mana=50; this.stamina=100;
  this.inventory=[];
 }
}
