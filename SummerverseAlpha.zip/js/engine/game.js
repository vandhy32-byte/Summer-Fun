
import {Player} from '../entities/player.js';
import {QuestSystem} from '../systems/quests.js';
import {AchievementSystem} from '../systems/achievements.js';

export class Game{
 constructor(){
  this.canvas=document.getElementById('game');
  this.ctx=this.canvas.getContext('2d');
  this.player=new Player();
  this.quests=new QuestSystem();
  this.achievements=new AchievementSystem();
  this.keys={};
  addEventListener('keydown',e=>this.keys[e.key.toLowerCase()]=true);
  addEventListener('keyup',e=>this.keys[e.key.toLowerCase()]=false);
  this.resize(); addEventListener('resize',()=>this.resize());
 }
 resize(){this.canvas.width=innerWidth;this.canvas.height=innerHeight;}
 update(){
  if(this.keys.w)this.player.y-=3;
  if(this.keys.s)this.player.y+=3;
  if(this.keys.a)this.player.x-=3;
  if(this.keys.d)this.player.x+=3;
 }
 render(){
  this.ctx.fillStyle='#1b2740';
  this.ctx.fillRect(0,0,this.canvas.width,this.canvas.height);
  this.ctx.fillStyle='cyan';
  this.ctx.beginPath();
  this.ctx.arc(this.player.x,this.player.y,15,0,Math.PI*2);
  this.ctx.fill();
 }
 start(){
  const loop=()=>{this.update();this.render();requestAnimationFrame(loop)};
  loop();
 }
}
